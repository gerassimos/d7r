<?php
$a_var="str";
echo "test concat a".$a_var." var";

echo "<p></p>";

echo "test concat a".date('H:i, jS F Y')." var"
?>
