<?php echo $_POST['name']; ?>

<?php echo (int)$_POST['age']; ?>



