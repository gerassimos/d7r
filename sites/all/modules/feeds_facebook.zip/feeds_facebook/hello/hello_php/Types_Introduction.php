<?php
$a_boo=TRUE;
$a_str='str1';
$a_str2="str2";
$a_int =1;

echo gettype($a_boo); echo $a_boo;
echo gettype($a_str); echo $a_str;
echo gettype($a_str2); echo $a_str2;


?>
