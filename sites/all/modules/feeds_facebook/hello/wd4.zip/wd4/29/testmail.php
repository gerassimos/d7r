<?php

mail('laura_xt@optusnet.com.au', 'test from php', 'message', 
     "From: laura@cs.rmit.edu.au\r\nCc: laura@cs.rmit.edu.au");

?>
