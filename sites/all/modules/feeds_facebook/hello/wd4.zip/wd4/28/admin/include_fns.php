<?php
  // All the include files for admin pages in the site
  include_once('../db_fns.php');
  include_once('user_auth_fns.php');
  session_start();
?>