<?php

require_once('page.inc');

$class = new ReflectionClass('Page');
echo '<pre>';
echo $class;
echo '</pre>';

?>
