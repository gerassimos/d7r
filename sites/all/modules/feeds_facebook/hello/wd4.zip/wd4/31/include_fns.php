<?php
  // putting all the include files here means 
  // that it will take time to load each one 
  // for every page, but that we wil not 
  // forget any

  include_once('db_fns.php');
  include_once('data_valid_fns.php');
  include_once('output_fns.php');
  include_once('discussion_fns.php');
  include_once('treenode_class.php');
?>
